const darkmenu = (prefix) => {
	return `

            COMANDOS:


  *Comandos do Leo:*

➸ *${prefix}loli*
➸ *${prefix}hentai*
➸ *${prefix}porno*
➸ *${prefix}boanoite*
➸ *${prefix}bomdia*
➸ *${prefix}boatarde*
➸ *${prefix}mia*
➸ *${prefix}mia1*
➸ *${prefix}mia2*
➸ *${prefix}belle*
➸ *${prefix}belle1*
➸ *${prefix}belle2*
➸ *${prefix}belle3*
➸ *${prefix}ayeko*

╔════════════════════
  TRADUZIDO POR *DARK*
  DUVIDAS? 👇
  WA.me/351965098553
╚════════════════════`
}

exports.darkmenu = darkmenu








